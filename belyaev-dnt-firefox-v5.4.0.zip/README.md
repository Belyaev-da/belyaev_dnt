# Belyaev DNT — Firefox

Версия для Mozilla Firefox 128+. Manifest V3, все функции защиты сохранены.

## Отличия от Chrome-версии

| Компонент | Chrome | Firefox |
|---|---|---|
| Фоновый процесс | Service Worker | Background Scripts |
| Модификация заголовков | declarativeNetRequest | webRequest.onBeforeSendHeaders |
| Блокировка доменов | declarativeNetRequest | declarativeNetRequest |
| MAIN-world инъекция | chrome.scripting (stable) | chrome.scripting (с FF 128) |

Заголовки обрабатываются через webRequest, потому что DNR modifyHeaders
в Firefox работает ненадёжно. Модуль `firefox-headers.js` загружается до
`background.js`, выставляет `self.__BDNT_FIREFOX_HEADERS = true`, по которому
background.js пропускает DNR-правила заголовков — блокировка доменов
остаётся на DNR. Минимальная версия Firefox: 128 (поддержка world MAIN).

## Установка

### Способ 1: временная (для тестирования)

1. Firefox → адресная строка: `about:debugging#/runtime/this-firefox`
2. **«Загрузить временное дополнение…»** → выбрать `manifest.json`
3. Работает до перезапуска браузера

### Способ 2: постоянная через подпись AMO

1. Зарегистрируйтесь на addons.mozilla.org
2. Упакуйте: `cd belyaev-dnt-firefox && zip -r ../bdnt-ff.zip . -x "*.DS_Store" "README*"`
3. addons.mozilla.org/developers/addon/submit/distribution → «Для собственного использования»
4. Загрузите ZIP → AMO подпишет → скачайте .xpi
5. Перетащите .xpi в окно Firefox → подтвердите

### Способ 3: неподписанная (Developer Edition / Nightly)

1. `about:config` → `xpinstall.signatures.required` = `false`
2. ZIP → переименовать в .xpi → перетащить в Firefox

## Проверка

После включения откройте browserleaks.com/javascript — User-Agent,
hardwareConcurrency, deviceMemory должны быть подменены. В Network DevTools
проверьте заголовки DNT: 1 и Sec-GPC: 1.

## Ограничения

- file:// не поддерживается (Firefox MV3)
- persistAcrossSessions недоступен — скрипты перерегистрируются при каждом запуске
- Временная установка сбрасывается при перезапуске
- Синхронную инъекцию в MAIN-мир нужно проверить вживую на Firefox 128+
