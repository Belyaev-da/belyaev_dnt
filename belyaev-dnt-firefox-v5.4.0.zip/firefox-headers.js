/*
 * Belyaev DNT — firefox-headers.js
 *
 * Firefox MV3: declarativeNetRequest modifyHeaders работает ненадёжно,
 * поэтому модификацию заголовков делаем через webRequest.onBeforeSendHeaders
 * с blocking — Firefox это поддерживает в MV3 (в отличие от Chrome).
 *
 * Этот скрипт загружается ДО background.js и выставляет глобальный флаг
 * self.__BDNT_FIREFOX_HEADERS = true, по которому background.js пропускает
 * DNR-правило RULE_HEADERS (блокировка доменов остаётся на DNR).
 */

self.__BDNT_FIREFOX_HEADERS = true;

(async function initFirefoxHeaders() {
  'use strict';

  // Ждём, пока background.js загрузит профили. Проверяем раз в 200 мс.
  function waitForProfiles() {
    return new Promise(resolve => {
      const check = () => {
        if (self.BelyaevProfiles) resolve(self.BelyaevProfiles);
        else setTimeout(check, 200);
      };
      check();
    });
  }

  const P = await waitForProfiles();

  async function getState() {
    const { isOn = false, level = P.DEFAULT_LEVEL } =
      await chrome.storage.local.get(['isOn', 'level']);
    return { isOn, level: String(level) };
  }

  async function getExcluded() {
    const { whitelist = [], siteRules = {} } =
      await chrome.storage.local.get(['whitelist', 'siteRules']);
    const set = new Set();
    whitelist.forEach(d => set.add(d.trim().toLowerCase()));
    Object.entries(siteRules).forEach(([d, r]) => {
      if (r === 'off') set.add(d.trim().toLowerCase());
    });
    return set;
  }

  function isExcluded(url, excludedSet) {
    try {
      const host = new URL(url).hostname.toLowerCase().replace(/^www\./, '');
      for (const d of excludedSet) {
        if (host === d || host.endsWith('.' + d)) return true;
      }
    } catch (e) {}
    return false;
  }

  // Собираем заголовки, которые нужно модифицировать, по текущему профилю.
  function buildHeaderOps(profile) {
    const setHeaders = {};
    const removeHeaders = new Set();

    if (profile.addDNT) {
      setHeaders['DNT'] = '1';
      setHeaders['Sec-GPC'] = '1';
    }

    for (const [name, value] of Object.entries(profile.spoofHeaders || {})) {
      setHeaders[name] = value;
    }

    if (profile.spoofClientHints && profile.spoofUserAgent) {
      setHeaders['Sec-CH-UA'] =
        '"Chromium";v="122", "Not(A:Brand";v="24", "Google Chrome";v="122"';
      setHeaders['Sec-CH-UA-Mobile'] = '?0';
      setHeaders['Sec-CH-UA-Platform'] = '"Windows"';
      ['Sec-CH-UA-Platform-Version', 'Sec-CH-UA-Full-Version-List',
       'Sec-CH-UA-Full-Version', 'Sec-CH-UA-Arch', 'Sec-CH-UA-Model',
       'Sec-CH-UA-Bitness'].forEach(h => removeHeaders.add(h.toLowerCase()));
    }

    for (const name of profile.stripHeaders || []) {
      removeHeaders.add(name.toLowerCase());
    }

    if (profile.blockAuthorization) {
      removeHeaders.add('authorization');
    }

    if (profile.trimReferrer) {
      // Referer удаляется только для third-party — обрабатывается отдельно.
    }

    return { setHeaders, removeHeaders, trimReferrer: !!profile.trimReferrer };
  }

  // Кэш: пересчитываем при изменении настроек.
  let cachedOps = null;
  let cachedExcluded = new Set();

  async function refresh() {
    const { isOn, level } = await getState();
    if (!isOn) { cachedOps = null; return; }
    cachedOps = buildHeaderOps(P.get(level));
    cachedExcluded = await getExcluded();
  }

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' &&
        (changes.isOn || changes.level || changes.whitelist || changes.siteRules)) {
      refresh();
    }
  });

  await refresh();

  // ── Listener ─────────────────────────────────────────────────────────
  chrome.webRequest.onBeforeSendHeaders.addListener(
    (details) => {
      if (!cachedOps) return {};
      if (isExcluded(details.url, cachedExcluded)) return {};

      const headers = details.requestHeaders || [];
      const ops = cachedOps;
      const lowerSet = new Map(); // lowercase name -> index

      headers.forEach((h, i) => lowerSet.set(h.name.toLowerCase(), i));

      // Удаляем заголовки.
      ops.removeHeaders.forEach(name => {
        const idx = lowerSet.get(name);
        if (idx !== undefined) headers[idx] = null;
      });

      // Устанавливаем заголовки (заменяем существующий или добавляем).
      for (const [name, value] of Object.entries(ops.setHeaders)) {
        const idx = lowerSet.get(name.toLowerCase());
        if (idx !== undefined) {
          headers[idx].value = value;
        } else {
          headers.push({ name, value });
        }
      }

      // Referer: удаляем только для third-party.
      if (ops.trimReferrer) {
        try {
          const reqHost = new URL(details.url).hostname;
          const idx = lowerSet.get('referer');
          if (idx !== undefined) {
            const refHost = new URL(headers[idx].value).hostname;
            if (refHost !== reqHost && !reqHost.endsWith('.' + refHost) &&
                !refHost.endsWith('.' + reqHost)) {
              headers[idx] = null;
            }
          }
        } catch (e) {}
      }

      return { requestHeaders: headers.filter(Boolean) };
    },
    { urls: ['<all_urls>'] },
    ['blocking', 'requestHeaders']
  );
})();
