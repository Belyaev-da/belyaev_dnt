/* Belyaev DNT — маркер режима "динамическая защита".
 * Регистрируется service worker'ом в том же массиве js[], что и
 * world/levelN.js — непосредственно перед engine.js. Выполняется
 * в MAIN-мире на document_start, поэтому движок читает режим
 * синхронно, без единого асинхронного вызова к chrome.storage. */
window.__BDNT_MODE__ = 'dynamic';
