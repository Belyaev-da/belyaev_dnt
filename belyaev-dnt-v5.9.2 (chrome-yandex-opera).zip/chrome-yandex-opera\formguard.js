/*
 * Belyaev DNT — formguard.js
 * ISOLATED, document_idle. Спрашивает у background, включена ли защита
 * и есть ли в профиле blockTrackers — если да, разрешает MAIN-скрипту
 * formguard-main.js начать наблюдение за полями форм (событие
 * bdnt-formguard-enable). Сама детекция «кражи до отправки» (перехват
 * геттера .value) выполняется в MAIN-мире — см. formguard-main.js,
 * почему это не может работать отсюда. Здесь же — UI уведомления,
 * которое приходит обратно через событие bdnt-formguard-alert.
 */
(function () {
  'use strict';
  if (window.top !== window.self) return;

  const KEY = '__bdnt_formguard_' + location.hostname;

  chrome.runtime.sendMessage({ type: 'getNoticeState' }, (st) => {
    if (chrome.runtime.lastError || !st || !st.isOn) return;
    if (!st.profile || !st.profile.blockTrackers) return;
    window.dispatchEvent(new CustomEvent('bdnt-formguard-enable'));
  });

  window.addEventListener('bdnt-formguard-alert', (e) => {
    const domains = (e.detail && e.detail.domains) || [];
    if (domains.length) warn(domains);
  });

  function warn(domains) {
    if (!document.body) return;
    try { if (sessionStorage.getItem(KEY)) return; sessionStorage.setItem(KEY, '1'); } catch (e) {}

    const holder = document.createElement('div');
    holder.style.cssText = 'all:initial;position:fixed;z-index:2147483647;left:16px;top:16px;';
    const root = holder.attachShadow({ mode: 'closed' });

    root.innerHTML = `
      <style>
        .c{box-sizing:border-box;width:305px;padding:14px;border-radius:14px;
          background:rgba(48,28,58,.93);backdrop-filter:blur(14px);
          border:1px solid rgba(200,150,255,.28);color:#F0E8F8;
          font:400 12.5px/1.5 'Segoe UI',system-ui,sans-serif;
          box-shadow:0 8px 28px rgba(0,0,0,.4);opacity:0;transform:translateY(-10px);
          transition:.3s ease;position:relative}
        .c.in{opacity:1;transform:translateY(0)}
        .h{font-weight:700;font-size:13px;color:#D9B3FF;display:flex;gap:7px;align-items:center}
        .t{margin-top:8px;color:rgba(240,232,248,.82);font-size:12px}
        .list{margin-top:8px;padding:8px;border-radius:8px;background:rgba(0,0,0,.25);
          font-family:monospace;font-size:11px;color:#E0C9FF}
        .rec{margin-top:9px;padding-top:9px;border-top:1px solid rgba(255,255,255,.12);
          font-size:11.5px;color:#C9A9E8}
        .x{position:absolute;top:9px;right:11px;background:none;border:none;
          color:rgba(255,255,255,.4);font-size:15px;cursor:pointer;line-height:1}
      </style>
      <div class="c">
        <button class="x">&times;</button>
        <div class="h">👁 Данные читают до отправки</div>
        <div class="t">Сторонние скрипты считывают то, что вы вводите в форму,
          ещё до нажатия кнопки «Отправить».</div>
        <div class="list fg-list"></div>
        <div class="rec">Даже если вы передумаете и не отправите форму,
          введённые данные уже могли уйти третьим лицам.</div>
      </div>`;

    document.body.appendChild(holder);
    const list = root.querySelector('.fg-list');
    domains.forEach(d => {
      const div = document.createElement('div');
      div.textContent = '• ' + d;
      list.appendChild(div);
    });

    const card = root.querySelector('.c');
    requestAnimationFrame(() => card.classList.add('in'));
    const hide = () => { card.classList.remove('in'); setTimeout(() => holder.remove(), 300); };
    root.querySelector('.x').addEventListener('click', hide);
    setTimeout(hide, 20000);
  }
})();
