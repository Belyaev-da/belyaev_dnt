/*
 * Belyaev DNT — formguard-main.js
 * MAIN, document_start. Перехватывает чтение .value полей форм ДО их
 * отправки — детект «кражи данных до submit» сторонними скриптами сайта.
 *
 * Живёт в MAIN-мире по той же причине, что и engine.js: перехват
 * геттера/сеттера должен быть установлен в том же JS-контексте, что и
 * скрипты страницы. Раньше вся эта логика жила в formguard.js в
 * ISOLATED-мире — там Object.defineProperty(el, 'value', …) подменяет
 * геттер только на ISOLATED-обёртке DOM-элемента. У страничных скриптов
 * своя, отдельная обёртка того же узла (стандартное поведение изоляции
 * контент-скриптов): они продолжают видеть нативный геттер и спокойно
 * читают value в обход подмены, а new Error().stack, снятый из ISOLATED,
 * не содержит фреймов сайта. Перехват просто никогда не срабатывал.
 *
 * Наблюдение стартует только после сигнала от ISOLATED-скрипта
 * formguard.js (событие bdnt-formguard-enable) — он один умеет спросить
 * chrome.storage, включена ли защита и профиль ли с blockTrackers.
 * MAIN-скрипты доступа к chrome.* API не имеют вообще.
 */
(function () {
  'use strict';
  if (window.top !== window.self) return;

  let started = false;
  let alerted = false;
  const suspects = new Set();

  window.addEventListener('bdnt-formguard-enable', function () {
    if (started) return;
    started = true;
    start();
  });

  function start() {
    watchFields();
    const mo = new MutationObserver(watchFields);
    mo.observe(document.documentElement, { childList: true, subtree: true });
  }

  function watchFields() {
    const fields = document.querySelectorAll(
      'input[type="email"], input[type="tel"], input[type="text"][name*="mail" i], ' +
      'input[type="text"][name*="phone" i], input[name*="name" i]'
    );
    fields.forEach(function (el) {
      if (el.__bdntGuard) return;
      el.__bdntGuard = true;

      // Ловим чтение .value сторонним кодом до submit
      let userTyped = false;
      let readCount = 0;

      el.addEventListener('input', function () { userTyped = true; }, { passive: true });

      // Перехватываем геттер value для конкретного элемента
      try {
        const proto = Object.getPrototypeOf(el);
        const desc = Object.getOwnPropertyDescriptor(proto, 'value');
        if (desc && desc.get && desc.set) {
          Object.defineProperty(el, 'value', {
            get() {
              // Читают значение, когда пользователь уже что-то ввёл,
              // но форма ещё не отправлена — подозрительно.
              if (userTyped && !el.__bdntSubmitting) {
                readCount++;
                if (readCount > 3 && !alerted) {
                  // Определяем, кто читает — по стеку вызовов
                  const stack = (new Error()).stack || '';
                  const m = stack.match(/https?:\/\/([^\/\s:)]+)/g) || [];
                  m.forEach(function (u) {
                    try {
                      const h = new URL(u).hostname;
                      if (h !== location.hostname && !h.endsWith('.' + location.hostname)) {
                        suspects.add(h);
                      }
                    } catch (e) {}
                  });
                  if (suspects.size > 0) {
                    alerted = true;
                    // Единственный канал MAIN → ISOLATED: DOM-событие на
                    // window. detail с массивом строк проходит структурное
                    // клонирование через границу миров, обычные JS-объекты
                    // (замыкания, DOM-узлы) — нет.
                    window.dispatchEvent(new CustomEvent('bdnt-formguard-alert', {
                      detail: { domains: Array.from(suspects).slice(0, 3) }
                    }));
                  }
                }
              }
              return desc.get.call(this);
            },
            set(v) { return desc.set.call(this, v); },
            configurable: true
          });
        }
      } catch (e) {}

      // Метим момент отправки
      const form = el.closest('form');
      if (form && !form.__bdntGuard) {
        form.__bdntGuard = true;
        form.addEventListener('submit', function () {
          form.querySelectorAll('input').forEach(function (i) { i.__bdntSubmitting = true; });
        }, true);
      }
    });
  }
})();
