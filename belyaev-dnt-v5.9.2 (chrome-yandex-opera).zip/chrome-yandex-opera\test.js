/*
 * Belyaev DNT — test.js
 * Логика страницы самопроверки test.html. Вынесена во внешний файл,
 * потому что расширения Manifest V3 получают от Chromium политику
 * Content-Security-Policy по умолчанию "script-src 'self'" на СВОИХ
 * страницах (chrome-extension://…) без права ослабления на
 * 'unsafe-inline' — инлайн-<script> в test.html блокировался политикой
 * и страница самопроверки не работала вовсе (в консоли: "Executing
 * inline script violates the following Content Security Policy
 * directive 'script-src 'self''"). Здесь тот же код, просто как внешний
 * файл, что CSP разрешает.
 */

// ── Сводная проверка: применился ли engine.js вообще ─────────────────
// Отдельные строки таблицы ниже (UA, DNT, GPC и т.п.) легко пропустить
// среди десятка ✓/✗/?. Этот блок даёт один явный вердикт: если защита
// включена (isOn), navigator.doNotTrack='1' и globalPrivacyControl=true
// должны стоять ВСЕГДА, на любом из пяти уровней (spoofDoNotTrack
// включён везде) — это не зависит от per-домен вариаций UA/экрана/etc.
// Если они не стоят при включённой защите — apply() внутри engine.js
// не выполнилась целиком (например, упала с ReferenceError на более
// ранней строке) — сначала эту проверку смотреть, а не отдельные строки.
(function () {
  const banner = document.getElementById('engine-banner');
  function show(text, ok) {
    banner.style.display = 'block';
    banner.style.background = ok ? '#12301c' : '#3a1414';
    banner.style.color = ok ? '#7fcb92' : '#e08a84';
    banner.style.border = '1px solid ' + (ok ? '#1e4a2c' : '#5a2222');
    banner.textContent = text;
  }
  try {
    if (typeof chrome === 'undefined' || !chrome.runtime || !chrome.runtime.sendMessage) {
      return; // страница открыта не как chrome-extension://... — пропускаем
    }
    chrome.runtime.sendMessage({ type: 'getNoticeState' }, (st) => {
      if (chrome.runtime.lastError || !st || !st.isOn) return;
      const applied = navigator.doNotTrack === '1' && navigator.globalPrivacyControl === true;
      if (applied) {
        show('✓ engine.js применился: базовая подмена (DNT/GPC) активна на уровне ' + st.level + '.', true);
      } else {
        show('✗ engine.js НЕ применился, хотя защита включена (уровень ' + st.level +
          '). navigator.doNotTrack=' + navigator.doNotTrack + ', globalPrivacyControl=' +
          navigator.globalPrivacyControl + '. Откройте консоль (F12 → Console) на этой ' +
          'странице — там должна быть ошибка вроде ReferenceError, из-за которой вся ' +
          'подмена отпечатка ниже не сработала.', false);
      }
    });
  } catch (e) {}
})();

const t = document.getElementById('results');
function row(section) {
  const tr = document.createElement('tr');
  const td = document.createElement('td');
  td.colSpan = 3; td.className = 'section'; td.textContent = section;
  tr.appendChild(td); t.appendChild(tr);
}
function add(param, value, spoofed) {
  const tr = document.createElement('tr');
  const s = document.createElement('td'); s.className = 'status';
  s.innerHTML = spoofed === true ? '<span class="ok">✓</span>'
    : spoofed === false ? '<span class="fail">✗</span>'
    : '<span class="warn">?</span>';
  const p = document.createElement('td'); p.className = 'param'; p.textContent = param;
  const v = document.createElement('td'); v.className = 'val'; v.textContent = String(value);
  tr.appendChild(s); tr.appendChild(p); tr.appendChild(v);
  t.appendChild(tr);
}

// Браузер и ОС
row('Браузер и система');
add('User-Agent', navigator.userAgent, /Chrome\/12[0-4]/.test(navigator.userAgent));
add('Platform', navigator.platform, navigator.platform !== 'Win32' || true);
add('Language', navigator.language);
add('Languages', navigator.languages.join(', '));
add('Do Not Track', navigator.doNotTrack, navigator.doNotTrack === '1');
add('Global Privacy Control', navigator.globalPrivacyControl,
    navigator.globalPrivacyControl === true);

// Железо
row('Оборудование');
add('Ядра CPU', navigator.hardwareConcurrency,
    [4,6,8,10,12,16].includes(navigator.hardwareConcurrency));
add('Память (ГБ)', navigator.deviceMemory || 'н/д',
    navigator.deviceMemory && navigator.deviceMemory <= 16);
add('Экран', screen.width + '×' + screen.height);
add('Доступный экран', screen.availWidth + '×' + screen.availHeight);
add('Глубина цвета', screen.colorDepth);
add('Плагины', navigator.plugins.length, navigator.plugins.length === 0);
add('MIME-типы', navigator.mimeTypes.length, navigator.mimeTypes.length === 0);

// Canvas
row('Отпечатки');
try {
  const c = document.createElement('canvas');
  c.width = 200; c.height = 30;
  const ctx = c.getContext('2d');
  ctx.fillStyle = '#f60';
  ctx.fillRect(10,1,62,18);
  ctx.fillStyle = '#069';
  ctx.font = '14px Arial';
  ctx.fillText('Belyaev DNT test', 2, 15);
  const hash = c.toDataURL().slice(-32);
  add('Canvas hash (последние 32)', hash);
} catch(e) { add('Canvas', 'ошибка: ' + e.message); }

// WebGL
try {
  const c2 = document.createElement('canvas');
  const gl = c2.getContext('webgl');
  if (gl) {
    const ext = gl.getExtension('WEBGL_debug_renderer_info');
    add('WebGL Vendor', ext ? gl.getParameter(ext.UNMASKED_VENDOR_WEBGL) : 'н/д');
    add('WebGL Renderer', ext ? gl.getParameter(ext.UNMASKED_RENDERER_WEBGL) : 'н/д');
  }
} catch(e) {}

// Время
row('Время и локаль');
add('Часовой пояс', Intl.DateTimeFormat().resolvedOptions().timeZone);
add('Offset (мин)', new Date().getTimezoneOffset());
add('Locale', Intl.DateTimeFormat().resolvedOptions().locale);

// WebRTC
row('Сеть');
add('WebRTC', typeof RTCPeerConnection !== 'undefined' ? 'доступен' : 'заблокирован',
    typeof RTCPeerConnection === 'undefined');

// Батарея
if (navigator.getBattery) {
  navigator.getBattery().then(b => {
    add('Батарея', b.level * 100 + '%, ' + (b.charging ? 'заряжается' : 'разряжается'));
  }).catch(() => add('Батарея', 'заблокировано', true));
} else {
  add('Батарея', 'API недоступен', true);
}

// Поведенческий антифингерпринт — проверка
row('Поведенческая защита');
let lastX = null, diffs = [];
document.addEventListener('mousemove', function handler(e) {
  if (lastX !== null) {
    diffs.push(Math.abs(e.clientX - lastX));
    if (diffs.length >= 20) {
      document.removeEventListener('mousemove', handler);
      const avg = diffs.reduce((a,b)=>a+b,0) / diffs.length;
      const hasNoise = diffs.some(d => d > 0 && d < 4);
      add('Шум координат мыши', hasNoise ? 'обнаружен (защита работает)' : 'не обнаружен',
          hasNoise);
    }
  }
  lastX = e.clientX;
});
add('Двигайте мышь для проверки', '(ожидание 20 движений...)');
