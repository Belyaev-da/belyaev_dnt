/*
 * Belyaev DNT — cookieconsent.js
 * ISOLATED, document_idle. Автоматически находит и нажимает «Отклонить»
 * или «Только необходимые» на GDPR/cookie-баннерах. Покрывает 10 основных
 * CMP-платформ (~80% сайтов). Если кнопка отклонения не найдена —
 * не трогает баннер (безопасный фолбэк).
 */
(function () {
  'use strict';
  if (window.top !== window.self) return;

  const SEEN_KEY = '__bdnt_cookie_' + location.hostname;
  try { if (sessionStorage.getItem(SEEN_KEY)) return; } catch (e) {}

  // Селекторы кнопок отклонения для основных CMP-платформ.
  // Порядок: сначала явные «отклонить», потом «только необходимые».
  // button[class*="reject"] сюда специально НЕ входит: без привязки к
  // баннеру-контейнеру он ловит любую кнопку "Reject" на странице
  // (отклонить платёж, отклонить приглашение и т.п. — см. ниже).
  const REJECT_SELECTORS = [
    // OneTrust
    '#onetrust-reject-all-handler',
    'button.onetrust-close-btn-handler',
    // Cookiebot
    '#CybotCookiebotDialogBodyButtonDecline',
    'a#CybotCookiebotDialogBodyLevelButtonLevelOptinDeclineAll',
    // TrustArc / TrustE
    '.truste_overlay .pdynamicbutton .call',
    // Quantcast / TCF
    'button.qc-cmp2-summary-buttons [mode="secondary"]',
    // Общие паттерны (по тексту кнопок)
    'button[data-testid="cookie-policy-manage-dialog-btn-reject-all"]',
    // Яндекс
    '.yconsent__button._type_reject',
    // Didomi
    '#didomi-notice-disagree-button',
    // Klaro
    'button.cm-btn-danger',
  ];

  // Тексты кнопок, которые означают «отклонить» (по подстроке, lowercase).
  const REJECT_TEXTS = [
    'reject all', 'decline all', 'deny all', 'refuse',
    'отклонить', 'только необходим', 'отказ', 'reject',
    'nur notwendige', 'tout refuser', 'rechazar todo',
    'necessary only', 'essential only'
  ];

  function tryDismiss() {
    // 1. Пробуем по селекторам. Это вендор-специфичные id/классы, которые
    // CMP-скрипт генерирует сам (например #onetrust-reject-all-handler) —
    // такое значение не встречается на кнопках вне баннера, поэтому
    // дополнительная проверка контейнера здесь не нужна.
    for (const sel of REJECT_SELECTORS) {
      try {
        const btn = document.querySelector(sel);
        if (btn && btn.offsetParent !== null) {
          btn.click();
          markDone();
          return true;
        }
      } catch (e) {}
    }

    // 2. Ищем кнопку по тексту — только внутри контейнеров-баннеров,
    // никогда по всей странице.
    const banners = document.querySelectorAll(
      '[id*="cookie" i], [class*="cookie" i], [id*="consent" i], [class*="consent" i], ' +
      '[id*="gdpr" i], [class*="gdpr" i], [role="dialog"][aria-label*="cookie" i]'
    );
    for (const banner of banners) {
      if (banner.offsetParent === null && banner !== document.body) continue;
      const buttons = banner.querySelectorAll('button, a[role="button"]');
      for (const btn of buttons) {
        if (btn.offsetParent === null) continue;
        const text = (btn.textContent || '').trim().toLowerCase();
        if (text.length > 50) continue; // слишком длинный — не кнопка
        for (const rt of REJECT_TEXTS) {
          if (text.includes(rt)) {
            btn.click();
            markDone();
            return true;
          }
        }
      }
    }
    return false;
  }

  function markDone() {
    try { sessionStorage.setItem(SEEN_KEY, '1'); } catch (e) {}
  }

  // Пробуем сразу, потом ещё 3 раза с задержкой (баннеры появляются не мгновенно).
  let attempts = 0;
  function attempt() {
    if (tryDismiss()) return;
    attempts++;
    if (attempts < 4) setTimeout(attempt, 1500);
  }

  // Стартуем через секунду после загрузки — даём баннеру отрисоваться.
  setTimeout(attempt, 1200);
})();
