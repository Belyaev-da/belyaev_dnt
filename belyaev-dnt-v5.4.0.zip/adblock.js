/*
 * Belyaev DNT — adblock.js
 * ISOLATED, document_start. Скрывает типовые рекламные контейнеры через
 * CSS (как в uBlock/AdBlock) — работает даже если баннер не с чужого
 * домена, а встроен в саму страницу. Дополняет сетевую блокировку
 * AD_DOMAINS в background.js.
 */
(function () {
  'use strict';
  if (window.top !== window.self) return;

  chrome.runtime.sendMessage({ type: 'getNoticeState' }, (st) => {
    if (chrome.runtime.lastError || !st || !st.isOn) return;
    const profile = st.profile || {};
    if (!profile.blockAds) return;
    run();
  });

  function run() {

  const SELECTORS = [
    '.adsbygoogle', 'ins.adsbygoogle', 'iframe[id^="google_ads_iframe"]',
    'div[id^="google_ads_"]', 'div[id*="-ad-"]', 'div[class*="ad-banner"]',
    'div[class^="ad-container"]', 'div[class*="advert"]',
    '[class*="banner-ad"]', '[id*="banner_ad"]', '[class^="sponsored-"]',
    '[data-ad-slot]', '[data-ad-client]', 'div[id^="div-gpt-ad"]',
    'iframe[src*="doubleclick.net"]', 'iframe[src*="googlesyndication.com"]',
    'iframe[src*="adnxs.com"]', 'iframe[src*="taboola.com"]',
    'iframe[src*="outbrain.com"]', '.taboola-placeholder',
    'div[class*="popunder"]', 'div[id*="popunder"]',
    '.ob-widget', '.OUTBRAIN', 'ins.ad-slot', 'div.ad-slot-container'
  ];

  const style = document.createElement('style');
  style.textContent = SELECTORS.join(',\n') +
    ' { display: none !important; visibility: hidden !important; ' +
    'height: 0 !important; min-height: 0 !important; }';
  (document.head || document.documentElement).appendChild(style);

  // Догоняем контейнеры, добавленные динамически после первичной отрисовки.
  function sweep(root) {
    try {
      root.querySelectorAll(SELECTORS.join(',')).forEach(el => {
        el.style.setProperty('display', 'none', 'important');
      });
    } catch (e) {}
  }

  function start() {
    sweep(document);
    const mo = new MutationObserver(muts => {
      for (const m of muts) {
        if (m.addedNodes && m.addedNodes.length) { sweep(document); break; }
      }
    });
    mo.observe(document.documentElement, { childList: true, subtree: true });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', start, { once: true });
  } else {
    start();
  }
  } // конец run()
})();
