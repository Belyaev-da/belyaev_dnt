/*
 * Belyaev DNT — cookieconsent.js
 * ISOLATED, document_idle. Автоматически находит и нажимает «Отклонить»
 * или «Только необходимые» на GDPR/cookie-баннерах. Покрывает 10 основных
 * CMP-платформ (~80% сайтов). Если кнопка отклонения не найдена —
 * не трогает баннер (безопасный фолбэк).
 */
(function () {
  'use strict';
  if (window.top !== window.self) return;

  const SEEN_KEY = '__bdnt_cookie_' + location.hostname;
  try { if (sessionStorage.getItem(SEEN_KEY)) return; } catch (e) {}

  // Селекторы кнопок отклонения для основных CMP-платформ.
  // Порядок: сначала явные «отклонить», потом «только необходимые».
  const REJECT_SELECTORS = [
    // OneTrust
    '#onetrust-reject-all-handler',
    'button.onetrust-close-btn-handler',
    // Cookiebot
    '#CybotCookiebotDialogBodyButtonDecline',
    'a#CybotCookiebotDialogBodyLevelButtonLevelOptinDeclineAll',
    // TrustArc / TrustE
    '.truste_overlay .pdynamicbutton .call',
    // Quantcast / TCF
    'button.qc-cmp2-summary-buttons [mode="secondary"]',
    'button[class*="reject"]',
    // Общие паттерны (по тексту кнопок)
    'button[data-testid="cookie-policy-manage-dialog-btn-reject-all"]',
    // Яндекс
    '.yconsent__button._type_reject',
    // Didomi
    '#didomi-notice-disagree-button',
    // Klaro
    'button.cm-btn-danger',
    // Generic — по aria-label и тексту (фолбэк)
    'button[aria-label*="eject"], button[aria-label*="ecline"]',
    'button[aria-label*="ткл"], button[aria-label*="тказ"]',
  ];

  // Тексты кнопок, которые означают «отклонить» (по подстроке, lowercase).
  const REJECT_TEXTS = [
    'reject all', 'decline all', 'deny all', 'refuse',
    'отклонить', 'только необходим', 'отказ', 'reject',
    'nur notwendige', 'tout refuser', 'rechazar todo',
    'necessary only', 'essential only'
  ];

  function tryDismiss() {
    // 1. Пробуем по селекторам
    for (const sel of REJECT_SELECTORS) {
      try {
        const btn = document.querySelector(sel);
        if (btn && btn.offsetParent !== null) {
          btn.click();
          markDone();
          return true;
        }
      } catch (e) {}
    }

    // 2. Ищем кнопку по тексту
    const buttons = document.querySelectorAll(
      'button, a[role="button"], [class*="cookie"] button, [class*="consent"] button, [id*="cookie"] button'
    );
    for (const btn of buttons) {
      if (btn.offsetParent === null) continue;
      const text = (btn.textContent || '').trim().toLowerCase();
      if (text.length > 50) continue; // слишком длинный — не кнопка
      for (const rt of REJECT_TEXTS) {
        if (text.includes(rt)) {
          btn.click();
          markDone();
          return true;
        }
      }
    }
    return false;
  }

  function markDone() {
    try { sessionStorage.setItem(SEEN_KEY, '1'); } catch (e) {}
  }

  // Пробуем сразу, потом ещё 3 раза с задержкой (баннеры появляются не мгновенно).
  let attempts = 0;
  function attempt() {
    if (tryDismiss()) return;
    attempts++;
    if (attempts < 4) setTimeout(attempt, 1500);
  }

  // Стартуем через секунду после загрузки — даём баннеру отрисоваться.
  setTimeout(attempt, 1200);
})();
