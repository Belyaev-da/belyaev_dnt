/*
 * Belyaev DNT — sitedetect.js
 * ISOLATED, document_idle. Определяет тип сайта по DOM-признакам и
 * предлагает оптимальный уровень защиты, если текущий может ломать сайт.
 * Показывает ненавязчивое предложение один раз на домен.
 */
(function () {
  'use strict';
  if (window.top !== window.self) return;

  const HOST = location.hostname;
  const SEEN_KEY = '__bdnt_detect_' + HOST;
  try { if (sessionStorage.getItem(SEEN_KEY)) return; } catch (e) {}

  chrome.runtime.sendMessage({ type: 'getNoticeState' }, (st) => {
    if (chrome.runtime.lastError || !st || !st.isOn) return;

    const level = Number(st.level) || 2;
    const detected = detectSiteType();
    if (!detected || detected.recommended >= level) return;

    // Сайт может ломаться на текущем уровне — предлагаем понизить.
    try { sessionStorage.setItem(SEEN_KEY, '1'); } catch (e) {}
    setTimeout(() => showSuggestion(detected, level), 3000);
  });

  function detectSiteType() {
    const h = HOST.toLowerCase();
    const title = (document.title || '').toLowerCase();
    const html = document.documentElement.innerHTML.slice(0, 50000).toLowerCase();

    // Банки и платёжные системы
    if (/bank|sber|tinkoff|alfa-bank|vtb|raiffeisen|paypal|stripe/i.test(h) ||
        html.includes('card-number') || html.includes('cvv') ||
        document.querySelectorAll('input[autocomplete*="cc-"]').length > 0) {
      return { type: 'Банк / платёжная система', recommended: 1, icon: '🏦',
        reason: 'Обнаружены формы оплаты. Рекомендуется уровень 1, чтобы не нарушить работу транзакций.' };
    }

    // CRM и бизнес-инструменты
    if (/amocrm|bitrix24|salesforce|hubspot|zoho|1c-bitrix|megaplan/i.test(h) ||
        /crm|erp|helpdesk/i.test(title)) {
      return { type: 'CRM / бизнес-инструмент', recommended: 1, icon: '💼',
        reason: 'Рабочий инструмент с API-интеграциями. На высоком уровне защиты могут не работать виджеты и аналитика.' };
    }

    // Google Workspace
    if (/docs\.google|sheets\.google|drive\.google|mail\.google|calendar\.google/i.test(h)) {
      return { type: 'Google Workspace', recommended: 1, icon: '📊',
        reason: 'Сервисы Google чувствительны к подмене заголовков и cookie.' };
    }

    // Соцсети — можно защищаться агрессивнее
    if (/facebook|instagram|twitter|x\.com|tiktok|vk\.com|ok\.ru|linkedin/i.test(h)) {
      return { type: 'Социальная сеть', recommended: 3, icon: '👥',
        reason: 'Соцсети активно собирают данные. Рекомендуется повышенный уровень.' };
    }

    // Маркетплейсы
    if (/amazon|ozon|wildberries|aliexpress|ebay|avito/i.test(h)) {
      return { type: 'Маркетплейс', recommended: 2, icon: '🛒',
        reason: 'Умеренная защита: не ломает корзину и авторизацию, но скрывает отпечаток.' };
    }

    return null; // не распознан — не трогаем
  }

  function showSuggestion(info, currentLevel) {
    if (!document.body) return;
    const holder = document.createElement('div');
    holder.style.cssText = 'all:initial;position:fixed;z-index:2147483647;right:16px;bottom:16px;';
    const root = holder.attachShadow({ mode: 'closed' });

    root.innerHTML = `
      <style>
        .c{box-sizing:border-box;width:310px;padding:14px;border-radius:14px;
          background:rgba(16,32,48,.92);backdrop-filter:blur(14px);
          border:1px solid rgba(255,255,255,.12);color:#E6F2F8;
          font:400 12.5px/1.5 'Segoe UI',system-ui,sans-serif;
          box-shadow:0 8px 28px rgba(0,0,0,.35);opacity:0;transform:translateY(10px);
          transition:.3s ease}
        .c.in{opacity:1;transform:translateY(0)}
        .h{display:flex;align-items:center;gap:8px;font-weight:600;font-size:13px}
        .ico{font-size:20px}
        .t{margin-top:8px;color:rgba(230,242,248,.78);font-size:12px}
        .btns{display:flex;gap:8px;margin-top:12px}
        .btn{flex:1;padding:9px;border-radius:8px;border:none;font:600 12px sans-serif;cursor:pointer}
        .apply{background:#25E5A5;color:#071522}
        .skip{background:rgba(255,255,255,.1);color:#9DB4C6}
        .x{position:absolute;top:10px;right:12px;background:none;border:none;
          color:rgba(255,255,255,.4);font-size:14px;cursor:pointer}
      </style>
      <div class="c" style="position:relative">
        <button class="x">&times;</button>
        <div class="h"><span class="ico sd-icon"></span><span class="sd-type"></span></div>
        <div class="t"><span class="sd-reason"></span><br>Текущий уровень: <b class="sd-cur"></b> → рекомендуемый: <b class="sd-rec"></b></div>
        <div class="btns">
          <button class="btn apply" id="__bdnt_apply"><span class="sd-applytxt"></span></button>
          <button class="btn skip" id="__bdnt_skip">Оставить</button>
        </div>
      </div>`;

    document.body.appendChild(holder);
    const q = s => root.querySelector(s);
    q('.sd-icon').textContent = info.icon;
    q('.sd-type').textContent = info.type;
    q('.sd-reason').textContent = info.reason;
    q('.sd-cur').textContent = currentLevel;
    q('.sd-rec').textContent = info.recommended;
    q('.sd-applytxt').textContent = 'Применить уровень ' + info.recommended;
    const card = root.querySelector('.c');
    requestAnimationFrame(() => card.classList.add('in'));

    const hide = () => { card.classList.remove('in'); setTimeout(() => holder.remove(), 300); };
    root.querySelector('.x').addEventListener('click', hide);
    root.querySelector('#__bdnt_skip').addEventListener('click', hide);
    root.querySelector('#__bdnt_apply').addEventListener('click', () => {
      chrome.runtime.sendMessage({
        type: 'setSiteRule', domain: HOST, level: String(info.recommended)
      });
      hide();
    });
    setTimeout(hide, 20000);
  }
})();
