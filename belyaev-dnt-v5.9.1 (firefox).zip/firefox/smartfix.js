/*
 * Belyaev DNT — smartfix.js
 * ISOLATED, document_idle. Детектирует признаки поломки сайта
 * (ошибки JS, пустые iframe, сломанные формы) и предлагает добавить
 * сайт в исключения или понизить уровень.
 */
(function () {
  'use strict';
  if (window.top !== window.self) return;

  const HOST = location.hostname;
  const KEY = '__bdnt_fix_' + HOST;
  try { if (sessionStorage.getItem(KEY)) return; } catch (e) {}

  let errorCount = 0;
  let brokenSignals = [];

  // Считаем JS-ошибки
  window.addEventListener('error', (e) => {
    errorCount++;
    if (e.message && /blocked|cors|refused|denied/i.test(e.message)) {
      brokenSignals.push('Ошибка доступа: ' + e.message.slice(0, 60));
    }
  });

  // Через 8 секунд проверяем признаки поломки
  setTimeout(() => {
    // Пустые iframe (могут быть заблокированные виджеты)
    const iframes = document.querySelectorAll('iframe');
    let emptyIframes = 0;
    iframes.forEach(f => {
      try {
        if (f.offsetWidth > 50 && f.offsetHeight > 50 && !f.src) emptyIframes++;
      } catch (e) {}
    });
    if (emptyIframes > 2) brokenSignals.push(emptyIframes + ' пустых iframe');

    // Формы без action (могут быть сломаны)
    const forms = document.querySelectorAll('form');
    let brokenForms = 0;
    forms.forEach(f => {
      if (f.querySelector('input[type="submit"], button[type="submit"]') &&
          !f.action) brokenForms++;
    });

    // Решаем, показывать ли предложение
    if (errorCount > 5 || brokenSignals.length > 0) {
      chrome.runtime.sendMessage({ type: 'checkCurrentSite' }, (res) => {
        if (chrome.runtime.lastError || !res || !res.host) return;
        if (res.excluded) return; // уже исключён
        try { sessionStorage.setItem(KEY, '1'); } catch (e) {}
        showFix(res.host, brokenSignals, errorCount);
      });
    }
  }, 8000);

  function showFix(host, signals, errors) {
    if (!document.body) return;
    const holder = document.createElement('div');
    holder.style.cssText = 'all:initial;position:fixed;z-index:2147483647;left:16px;bottom:16px;';
    const root = holder.attachShadow({ mode: 'closed' });

    const details = signals.length
      ? signals.slice(0, 3).join('; ')
      : errors + ' ошибок JavaScript';

    root.innerHTML = `
      <style>
        .c{box-sizing:border-box;width:300px;padding:13px;border-radius:14px;
          background:rgba(58,36,16,.92);backdrop-filter:blur(14px);
          border:1px solid rgba(242,200,121,.25);color:#F2E8D8;
          font:400 12.5px/1.5 'Segoe UI',system-ui,sans-serif;
          box-shadow:0 6px 24px rgba(0,0,0,.3);opacity:0;transform:translateY(10px);
          transition:.3s ease}
        .c.in{opacity:1;transform:translateY(0)}
        .h{font-weight:600;font-size:13px;color:#F2C879;display:flex;align-items:center;gap:6px}
        .t{margin-top:6px;color:rgba(242,232,216,.75);font-size:11.5px}
        .btns{display:flex;gap:8px;margin-top:10px}
        .btn{flex:1;padding:8px;border-radius:8px;border:none;font:600 11.5px sans-serif;cursor:pointer}
        .fix{background:#F2C879;color:#2A1E00}
        .skip{background:rgba(255,255,255,.1);color:#C9B896}
        .x{position:absolute;top:8px;right:10px;background:none;border:none;
          color:rgba(255,255,255,.35);font-size:14px;cursor:pointer}
      </style>
      <div class="c" style="position:relative">
        <button class="x">&times;</button>
        <div class="h">⚠ Сайт может работать некорректно</div>
        <div class="t"><span class="sf-host"></span>: <span class="sf-details"></span>. Возможно, защита влияет на работу сайта.</div>
        <div class="btns">
          <button class="btn fix" id="__bdnt_fixsite">Понизить до уровня 1</button>
          <button class="btn skip" id="__bdnt_fixskip">Игнорировать</button>
        </div>
      </div>`;

    document.body.appendChild(holder);
    const sfHost = root.querySelector('.sf-host');
    const sfDet = root.querySelector('.sf-details');
    if (sfHost) sfHost.textContent = host;
    if (sfDet) sfDet.textContent = details;
    const card = root.querySelector('.c');
    requestAnimationFrame(() => card.classList.add('in'));
    const hide = () => { card.classList.remove('in'); setTimeout(() => holder.remove(), 300); };
    root.querySelector('.x').addEventListener('click', hide);
    root.querySelector('#__bdnt_fixskip').addEventListener('click', hide);
    root.querySelector('#__bdnt_fixsite').addEventListener('click', () => {
      chrome.runtime.sendMessage({ type: 'setSiteRule', domain: host, level: '1' });
      hide();
      // Перезагрузка для применения
      setTimeout(() => location.reload(), 500);
    });
    setTimeout(hide, 15000);
  }
})();
