/*
 * Belyaev DNT — leakcheck.js
 * ISOLATED, document_idle. Обнаруживает ввод email в формы и предупреждает,
 * если домен этого сайта ранее фигурировал в известных утечках.
 * Проверка ЛОКАЛЬНАЯ — email никуда не отправляется.
 */
(function () {
  'use strict';
  if (window.top !== window.self) return;

  const HOST = location.hostname.replace(/^www\./, '');
  const KEY = '__bdnt_leak_' + HOST;
  try { if (sessionStorage.getItem(KEY)) return; } catch (e) {}

  // Домены с публично известными крупными утечками данных.
  // Источник: публичные отчёты об инцидентах. Список обновляется с плагином.
  const BREACHED = {
    'linkedin.com': { year: 2021, count: '700 млн', what: 'профили, email, телефоны' },
    'facebook.com': { year: 2021, count: '533 млн', what: 'телефоны, email, локация' },
    'adobe.com': { year: 2013, count: '153 млн', what: 'email, пароли, подсказки' },
    'dropbox.com': { year: 2012, count: '68 млн', what: 'email, хеши паролей' },
    'tumblr.com': { year: 2013, count: '65 млн', what: 'email, пароли' },
    'myspace.com': { year: 2008, count: '360 млн', what: 'email, пароли' },
    'canva.com': { year: 2019, count: '137 млн', what: 'email, имена, города' },
    'zynga.com': { year: 2019, count: '172 млн', what: 'email, пароли, телефоны' },
    'wattpad.com': { year: 2020, count: '270 млн', what: 'email, пароли, IP' },
    'twitter.com': { year: 2022, count: '5.4 млн', what: 'email, телефоны' },
    'x.com': { year: 2022, count: '5.4 млн', what: 'email, телефоны' },
    'deezer.com': { year: 2022, count: '229 млн', what: 'email, даты рождения, IP' },
    'duolingo.com': { year: 2023, count: '2.6 млн', what: 'email, имена' },
    'vk.com': { year: 2012, count: '100 млн', what: 'email, пароли, телефоны' },
    'rambler.ru': { year: 2012, count: '98 млн', what: 'email, пароли' },
    'mail.ru': { year: 2014, count: '25 млн', what: 'email, пароли' },
    '500px.com': { year: 2018, count: '14.8 млн', what: 'email, имена, пол' },
    'chegg.com': { year: 2018, count: '40 млн', what: 'email, пароли, адреса' },
    'zoosk.com': { year: 2011, count: '29 млн', what: 'email, пароли' },
    'edmodo.com': { year: 2017, count: '77 млн', what: 'email, пароли' }
  };

  function findBreach() {
    if (BREACHED[HOST]) return { domain: HOST, ...BREACHED[HOST] };
    for (const d in BREACHED) {
      if (HOST.endsWith('.' + d)) return { domain: d, ...BREACHED[d] };
    }
    return null;
  }

  const breach = findBreach();
  if (!breach) return;

  // Ждём, пока пользователь начнёт вводить email или пароль
  function watchInputs() {
    const inputs = document.querySelectorAll(
      'input[type="email"], input[type="password"], input[name*="mail" i], input[id*="mail" i]'
    );
    inputs.forEach(el => {
      if (el.__bdntLeak) return;
      el.__bdntLeak = true;
      el.addEventListener('focus', onFocus, { once: true });
    });
  }

  function onFocus() {
    try { if (sessionStorage.getItem(KEY)) return; } catch (e) {}
    try { sessionStorage.setItem(KEY, '1'); } catch (e) {}
    showWarning(breach);
    if (mo) mo.disconnect();
  }

  function showWarning(b) {
    if (!document.body) return;
    const holder = document.createElement('div');
    holder.style.cssText = 'all:initial;position:fixed;z-index:2147483647;right:16px;top:16px;';
    const root = holder.attachShadow({ mode: 'closed' });

    root.innerHTML = `
      <style>
        .c{box-sizing:border-box;width:310px;padding:14px;border-radius:14px;
          background:rgba(58,20,20,.93);backdrop-filter:blur(14px);
          border:1px solid rgba(255,120,120,.3);color:#F8E8E8;
          font:400 12.5px/1.5 'Segoe UI',system-ui,sans-serif;
          box-shadow:0 8px 28px rgba(0,0,0,.4);opacity:0;transform:translateY(-10px);
          transition:.3s ease;position:relative}
        .c.in{opacity:1;transform:translateY(0)}
        .h{font-weight:700;font-size:13px;color:#FF9B9B;display:flex;align-items:center;gap:7px}
        .t{margin-top:8px;color:rgba(248,232,232,.82);font-size:12px}
        .stat{margin-top:8px;padding:8px;border-radius:8px;background:rgba(0,0,0,.25);font-size:11.5px}
        .rec{margin-top:9px;padding-top:9px;border-top:1px solid rgba(255,255,255,.12);
          font-size:11.5px;color:#FFC9C9}
        .x{position:absolute;top:9px;right:11px;background:none;border:none;
          color:rgba(255,255,255,.4);font-size:15px;cursor:pointer;line-height:1}
      </style>
      <div class="c">
        <button class="x">&times;</button>
        <div class="h">🔓 Утечка данных в прошлом</div>
        <div class="t">Сайт <b class="lk-domain"></b> ранее допускал утечку
          пользовательских данных.</div>
        <div class="stat">
          <b class="lk-year"></b> · пострадало <b class="lk-count"></b> аккаунтов<br>
          Утекло: <span class="lk-what"></span>
        </div>
        <div class="rec">Используйте уникальный пароль для этого сайта и
          включите двухфакторную аутентификацию, если она доступна.</div>
      </div>`;

    document.body.appendChild(holder);
    const q = s => root.querySelector(s);
    q('.lk-domain').textContent = b.domain;
    q('.lk-year').textContent = b.year;
    q('.lk-count').textContent = b.count;
    q('.lk-what').textContent = b.what;

    const card = root.querySelector('.c');
    requestAnimationFrame(() => card.classList.add('in'));
    const hide = () => { card.classList.remove('in'); setTimeout(() => holder.remove(), 300); };
    q('.x').addEventListener('click', hide);
    setTimeout(hide, 18000);
  }

  watchInputs();
  const mo = new MutationObserver(watchInputs);
  mo.observe(document.documentElement, { childList: true, subtree: true });
})();
