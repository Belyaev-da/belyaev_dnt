/*
 * Belyaev DNT — formguard.js
 * ISOLATED, document_idle. Обнаруживает «кражу до отправки»: скрипты
 * третьих сторон читают введённые в форму данные (email, телефон) ещё
 * до нажатия «Отправить» и передают их трекерам. Это массовая практика
 * маркетинговых платформ, о которой пользователь не знает.
 */
(function () {
  'use strict';
  if (window.top !== window.self) return;

  const KEY = '__bdnt_formguard_' + location.hostname;
  let alerted = false;
  const suspects = new Set();

  chrome.runtime.sendMessage({ type: 'getNoticeState' }, (st) => {
    if (chrome.runtime.lastError || !st || !st.isOn) return;
    if (!st.profile || !st.profile.blockTrackers) return;
    start();
  });

  function start() {
    watchFields();
    const mo = new MutationObserver(watchFields);
    mo.observe(document.documentElement, { childList: true, subtree: true });
  }

  function watchFields() {
    const fields = document.querySelectorAll(
      'input[type="email"], input[type="tel"], input[type="text"][name*="mail" i], ' +
      'input[type="text"][name*="phone" i], input[name*="name" i]'
    );
    fields.forEach(el => {
      if (el.__bdntGuard) return;
      el.__bdntGuard = true;

      // Ловим чтение .value сторонним кодом до submit
      let userTyped = false;
      let readCount = 0;

      el.addEventListener('input', () => { userTyped = true; }, { passive: true });

      // Перехватываем геттер value для конкретного элемента
      try {
        const proto = Object.getPrototypeOf(el);
        const desc = Object.getOwnPropertyDescriptor(proto, 'value');
        if (desc && desc.get && desc.set) {
          Object.defineProperty(el, 'value', {
            get() {
              // Читают значение, когда пользователь уже что-то ввёл,
              // но форма ещё не отправлена — подозрительно.
              if (userTyped && !el.__bdntSubmitting) {
                readCount++;
                if (readCount > 3 && !alerted) {
                  // Определяем, кто читает — по стеку вызовов
                  const stack = (new Error()).stack || '';
                  const m = stack.match(/https?:\/\/([^\/\s:)]+)/g) || [];
                  m.forEach(u => {
                    try {
                      const h = new URL(u).hostname;
                      if (h !== location.hostname && !h.endsWith('.' + location.hostname)) {
                        suspects.add(h);
                      }
                    } catch (e) {}
                  });
                  if (suspects.size > 0) {
                    alerted = true;
                    warn(Array.from(suspects).slice(0, 3));
                  }
                }
              }
              return desc.get.call(this);
            },
            set(v) { return desc.set.call(this, v); },
            configurable: true
          });
        }
      } catch (e) {}

      // Метим момент отправки
      const form = el.closest('form');
      if (form && !form.__bdntGuard) {
        form.__bdntGuard = true;
        form.addEventListener('submit', () => {
          form.querySelectorAll('input').forEach(i => { i.__bdntSubmitting = true; });
        }, true);
      }
    });
  }

  function warn(domains) {
    if (!document.body) return;
    try { if (sessionStorage.getItem(KEY)) return; sessionStorage.setItem(KEY, '1'); } catch (e) {}

    const holder = document.createElement('div');
    holder.style.cssText = 'all:initial;position:fixed;z-index:2147483647;left:16px;top:16px;';
    const root = holder.attachShadow({ mode: 'closed' });

    root.innerHTML = `
      <style>
        .c{box-sizing:border-box;width:305px;padding:14px;border-radius:14px;
          background:rgba(48,28,58,.93);backdrop-filter:blur(14px);
          border:1px solid rgba(200,150,255,.28);color:#F0E8F8;
          font:400 12.5px/1.5 'Segoe UI',system-ui,sans-serif;
          box-shadow:0 8px 28px rgba(0,0,0,.4);opacity:0;transform:translateY(-10px);
          transition:.3s ease;position:relative}
        .c.in{opacity:1;transform:translateY(0)}
        .h{font-weight:700;font-size:13px;color:#D9B3FF;display:flex;gap:7px;align-items:center}
        .t{margin-top:8px;color:rgba(240,232,248,.82);font-size:12px}
        .list{margin-top:8px;padding:8px;border-radius:8px;background:rgba(0,0,0,.25);
          font-family:monospace;font-size:11px;color:#E0C9FF}
        .rec{margin-top:9px;padding-top:9px;border-top:1px solid rgba(255,255,255,.12);
          font-size:11.5px;color:#C9A9E8}
        .x{position:absolute;top:9px;right:11px;background:none;border:none;
          color:rgba(255,255,255,.4);font-size:15px;cursor:pointer;line-height:1}
      </style>
      <div class="c">
        <button class="x">&times;</button>
        <div class="h">👁 Данные читают до отправки</div>
        <div class="t">Сторонние скрипты считывают то, что вы вводите в форму,
          ещё до нажатия кнопки «Отправить».</div>
        <div class="list fg-list"></div>
        <div class="rec">Даже если вы передумаете и не отправите форму,
          введённые данные уже могли уйти третьим лицам.</div>
      </div>`;

    document.body.appendChild(holder);
    const list = root.querySelector('.fg-list');
    domains.forEach(d => {
      const div = document.createElement('div');
      div.textContent = '• ' + d;
      list.appendChild(div);
    });

    const card = root.querySelector('.c');
    requestAnimationFrame(() => card.classList.add('in'));
    const hide = () => { card.classList.remove('in'); setTimeout(() => holder.remove(), 300); };
    root.querySelector('.x').addEventListener('click', hide);
    setTimeout(hide, 20000);
  }
})();
