/*
 * Belyaev DNT — mode.js
 * ISOLATED, document_start. Читает режим защиты из chrome.storage и
 * ставит data-bdnt-mode на <html>, откуда engine.js (MAIN) его считает.
 * Должен регистрироваться ДО engine.js.
 */
(function () {
  'use strict';
  try {
    chrome.storage.local.get('protectionMode', (r) => {
      if (chrome.runtime.lastError) return;
      const mode = (r && r.protectionMode === 'dynamic') ? 'dynamic' : 'static';
      try {
        document.documentElement.setAttribute('data-bdnt-mode', mode);
      } catch (e) {}
    });
  } catch (e) {}
})();
